package tutorappointmentsystem;


public class UserSession {
    private static int userId;
    private static String studentId;
    private static String fullName;
    private static String email;
    private static String role;

    public static void setUser(int id, String studentID, String name,
                               String userEmail, String userRole) {

        userId = id;
        studentId = studentID;
        fullName = name;
        email = userEmail;
        role = userRole;
    }

    public static int getUserId() {
        return userId;
    }

    public static String getStudentId() {
        return studentId;
    }

    public static String getFullName() {
        return fullName;
    }

    public static String getEmail() {
        return email;
    }

    public static String getRole() {
        return role;
    }

    public static void clearSession() {
        userId = 0;
        studentId = null;
        fullName = null;
        email = null;
        role = null;
    }
}
