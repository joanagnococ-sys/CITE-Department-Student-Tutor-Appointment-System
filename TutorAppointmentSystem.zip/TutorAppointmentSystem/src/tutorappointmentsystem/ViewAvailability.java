/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tutorappointmentsystem;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Component;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import com.toedter.calendar.JCalendar;

public class ViewAvailability extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ViewAvailability.class.getName());

    
    private String tutorName;
    private String subject;
    private String selectedTime = "";
    private LocalDate selectedDate;
    private LocalDate today = LocalDate.now();
    private boolean updateMode = false;
    private int appointmentId;

    public ViewAvailability() {
         initComponents();
         
    }   
    
    
    public ViewAvailability(String tutorName, String subject) {
    initComponents();

    this.tutorName = tutorName;
    this.subject = subject;
    this.updateMode = false;

    tutorNameLabel.setText(tutorName);
    subjectNameLabel.setText(subject);
    titleLabel.setText("View and Book Appointment");

    setupCalendarColors();
    setupSessionType();
    setupTimeComboBox();

    dateChooser.addPropertyChangeListener("date", e -> {
        java.util.Date chosenDate = dateChooser.getDate();
        if (chosenDate == null) {
            timeStatusLabel.setText("Please select a date");
            timeStatusLabel.setForeground(Color.RED);
            timeComboBox.removeAllItems();
            return;
        }

        LocalDate selectedDate = chosenDate.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        if (selectedDate.isBefore(LocalDate.now())
                || !isTutorAvailable(selectedDate)) {
            timeStatusLabel.setText("Date Unavailable");
            timeStatusLabel.setForeground(Color.RED);
            timeComboBox.removeAllItems();
        } else {
            setupTimeComboBox();
            checkTimeAvailability();
        }
    });

    timeComboBox.addActionListener(e -> checkTimeAvailability());
}


 
    
   private void setupSessionType() {
    sessionTypeComboBox.removeAllItems();

    sessionTypeComboBox.addItem("Online");
    sessionTypeComboBox.addItem("Face-to-Face");

    roomComboBox.removeAllItems();

    roomComboBox.addItem("MS CL-1");
    roomComboBox.addItem("MS CL-2");
    roomComboBox.addItem("MS CL-3");
    roomComboBox.addItem("SHS CL-1");
    roomComboBox.addItem("SHS CL-2");

    roomComboBox.setVisible(false);
}
    
    private String getSubjectTime(String subject) {
    String sql = "SELECT start_time, end_time "
               + "FROM tutors WHERE subject = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, subject);

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
                java.sql.Time start = rs.getTime("start_time");
                java.sql.Time end = rs.getTime("end_time");

                if (start != null && end != null) {
                    DateTimeFormatter formatter =
                            DateTimeFormatter.ofPattern("h:mm a");

                    return start.toLocalTime().format(formatter)
                            + " - "
                            + end.toLocalTime().format(formatter);
                }
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
                "Unable to load tutor schedule: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE);
    }

    return "";
}
    
    private boolean isTutorAvailable(LocalDate date) {

    DayOfWeek day = date.getDayOfWeek();

    switch (subject) {
        case "IT Project Management":
            return day == DayOfWeek.MONDAY
                    || day == DayOfWeek.TUESDAY
                    || day == DayOfWeek.WEDNESDAY;

        case "Data Structure & Algorithm":
            return day == DayOfWeek.TUESDAY
                    || day == DayOfWeek.WEDNESDAY
                    || day == DayOfWeek.THURSDAY;

        case "Information Management":
            return day == DayOfWeek.TUESDAY
                    || day == DayOfWeek.WEDNESDAY
                    || day == DayOfWeek.THURSDAY
                    || day == DayOfWeek.FRIDAY;

        case "Networking":
            return day == DayOfWeek.TUESDAY
                    || day == DayOfWeek.WEDNESDAY;

        case "Object Oriented Programming":
            return day == DayOfWeek.THURSDAY
                    || day == DayOfWeek.FRIDAY;

        default:
            return false;
    }
}
    
        
    private void setupCalendarColors() {

    dateChooser.getJCalendar().getDayChooser().addPropertyChangeListener(
            "day",
            e -> colorCalendarDates()
    );

    dateChooser.getJCalendar().getDayChooser().addPropertyChangeListener(
            "month",
            e -> colorCalendarDates()
    );

    dateChooser.getJCalendar().getDayChooser().addPropertyChangeListener(
            "year",
            e -> colorCalendarDates()
    );

    colorCalendarDates();
}
    

private void colorCalendarDates() {

    Calendar displayedMonth = dateChooser.getJCalendar().getCalendar();

    for (Component component :
            dateChooser.getJCalendar().getDayChooser().getDayPanel().getComponents()) {

        if (component instanceof JButton) {

            JButton button = (JButton) component;

            String text = button.getText().trim();

            if (text.matches("\\d{1,2}")) {

                int day = Integer.parseInt(text);

                Calendar date = (Calendar) displayedMonth.clone();
                date.set(Calendar.DAY_OF_MONTH, day);

                LocalDate localDate = LocalDate.of(
                        date.get(Calendar.YEAR),
                        date.get(Calendar.MONTH) + 1,
                        day
                );

                boolean available =
                        !localDate.isBefore(LocalDate.now())
                        && isTutorAvailable(localDate);

                button.setOpaque(true);
                button.setContentAreaFilled(true);

                if (available) {
                    button.setBackground(new Color(34, 197, 94));
                    button.setForeground(Color.BLACK);
                } else {
                    button.setBackground(new Color(239, 68, 68));
                    button.setForeground(Color.WHITE);
                }
            }
        }
    }

    dateChooser.getJCalendar().repaint();
}
    private void setupTimeComboBox() {

    timeComboBox.removeAllItems();

    timeStatusLabel.setText("Select a time");

    String timeRange = getSubjectTime(subject);

    if (timeRange == null || timeRange.isEmpty()) {
        return;
    }

    DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("h:mm a");

    String[] times = timeRange.split(" - ");

    LocalTime start = LocalTime.parse(times[0], formatter);
    LocalTime end = LocalTime.parse(times[1], formatter);

    while (!start.plusHours(1).isAfter(end)) {

        LocalTime slotEnd = start.plusHours(1);

        String slot = start.format(formatter)
                + " - "
                + slotEnd.format(formatter);

        timeComboBox.addItem(slot);

        start = slotEnd;
    }
}
    
private void checkTimeAvailability() {

    if (dateChooser == null
            || timeComboBox.getSelectedItem() == null) {
        timeStatusLabel.setText("Select a time");
        return;
    }

    Date selected = dateChooser.getDate();
    if (selected == null) {
        timeStatusLabel.setText("Please select a date");
        return;
    }

    LocalDate appointmentDate = selected.toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDate();

    String selectedSlot = timeComboBox.getSelectedItem().toString();
    String[] times = selectedSlot.split(" - ");

    DateTimeFormatter formatter =
            DateTimeFormatter.ofPattern("h:mm a");

    LocalTime startTime = LocalTime.parse(times[0], formatter);
    LocalTime endTime = LocalTime.parse(times[1], formatter);

    String sql =
            "SELECT COUNT(*) FROM appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "JOIN users u ON t.user_id = u.user_id "
            + "WHERE u.full_name = ? "
            + "AND a.subject = ? "
            + "AND a.appointment_date = ? "
            + "AND a.start_time < ? "
            + "AND a.end_time > ? "
            + "AND a.status IN ('Pending', 'Accepted') "
            + "AND (? = 0 OR a.appointment_id <> ?)";

    try (Connection conn = DBConnection.getConnection()) {

        if (conn == null) {
            timeStatusLabel.setText("Unable to check availability");
            return;
        }

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, tutorName);
            pst.setString(2, subject);
            pst.setDate(3, java.sql.Date.valueOf(appointmentDate));
            pst.setTime(4, java.sql.Time.valueOf(endTime));
            pst.setTime(5, java.sql.Time.valueOf(startTime));
            pst.setInt(6, updateMode ? appointmentId : 0);
            pst.setInt(7, updateMode ? appointmentId : 0);

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    timeStatusLabel.setText("Booked");
                    timeStatusLabel.setForeground(Color.RED);
                } else {
                    timeStatusLabel.setText("Available");
                    timeStatusLabel.setForeground(new Color(22, 163, 74));
                }
            }
        }

    } catch (SQLException e) {
        timeStatusLabel.setText("Unable to check availability");

        JOptionPane.showMessageDialog(
                this,
                "Error checking time availability: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    public ViewAvailability(int appointmentId, String tutorName, String subject) {
    initComponents();

    this.appointmentId = appointmentId;
    this.updateMode = true;
    this.tutorName = tutorName;
    this.subject = subject;

    tutorNameLabel.setText(tutorName);
    subjectNameLabel.setText(subject);
    titleLabel.setText("Update Appointment");
    titleDescription.setText("Edit your booked appointment details and save your changes.");

    setupCalendarColors();
    setupSessionType();
    setupTimeComboBox();

    dateChooser.addPropertyChangeListener("date", e -> {
        java.util.Date chosenDate = dateChooser.getDate();
        if (chosenDate == null) {
            timeStatusLabel.setText("Please select a date");
            timeStatusLabel.setForeground(Color.RED);
            timeComboBox.removeAllItems();
            return;
        }

        LocalDate selectedDate = chosenDate.toInstant()
                .atZone(ZoneId.systemDefault())
                .toLocalDate();

        if (selectedDate.isBefore(LocalDate.now())
                || !isTutorAvailable(selectedDate)) {
            timeStatusLabel.setText("Date Unavailable");
            timeStatusLabel.setForeground(Color.RED);
            timeComboBox.removeAllItems();
        } else {
            setupTimeComboBox();
            checkTimeAvailability();
        }
    });

    timeComboBox.addActionListener(e -> checkTimeAvailability());

    bookAppointment.setText("Save Changes");

    loadAppointmentDetails();
}
    
private void loadAppointmentDetails() {
    String sql = "SELECT appointment_date, start_time, end_time, "
            + "session_type, room, note "
            + "FROM appointments "
            + "WHERE appointment_id = ? AND student_id = ?";

    System.out.println("Appointment ID: " + appointmentId);
    System.out.println("Logged-in Student ID: "
            + UserSession.getStudentId());

    try (Connection conn = DBConnection.getConnection()) {
        if (conn == null) {
            return;
        }

        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, appointmentId);
            pst.setString(2, UserSession.getStudentId());

            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    java.sql.Date savedDate =
                            rs.getDate("appointment_date");

                    dateChooser.setDate(new java.util.Date(
                            savedDate.getTime()
                    ));

                    sessionTypeComboBox.setSelectedItem(
                            rs.getString("session_type"));

                    String savedRoom = rs.getString("room");

                    if (savedRoom != null) {
                        roomComboBox.setSelectedItem(savedRoom);
                    }

                    String savedNote = rs.getString("note");
                    note.setText(savedNote == null ? "" : savedNote);

                    DateTimeFormatter formatter =
                            DateTimeFormatter.ofPattern("h:mm a");

                    String savedTime =
                            rs.getTime("start_time").toLocalTime()
                                    .format(formatter)
                            + " - "
                            + rs.getTime("end_time").toLocalTime()
                                    .format(formatter);

                    timeComboBox.setSelectedItem(savedTime);
                    checkTimeAvailability();
                } else {
                    JOptionPane.showMessageDialog(
                            this,
                            "Appointment not found. Check the IDs in NetBeans Output.",
                            "Update Error",
                            JOptionPane.WARNING_MESSAGE
                    );
                }
            }
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Unable to load appointment: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    
 

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        titleDescription = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        sessionTypeComboBox = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        roomComboBox = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        note = new javax.swing.JTextArea();
        bookAppointment = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tutorNameLabel = new javax.swing.JLabel();
        subjectNameLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        timeComboBox = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        timeStatusLabel = new javax.swing.JLabel();
        dateChooser = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        titleLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setText("View Availability");

        titleDescription.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        titleDescription.setForeground(new java.awt.Color(255, 255, 255));
        titleDescription.setText("Check the tutor's available dates and book your appointment.");

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/calendar (3).png"))); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(titleLabel)
                    .addComponent(titleDescription))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel6)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                        .addComponent(titleLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(titleDescription)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 51, 102));

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 51, 102));
        jLabel14.setText("Select Date:");

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 51, 102));
        jLabel16.setText("Select Time:");

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 51, 102));
        jLabel19.setText("Session Type:");

        sessionTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        sessionTypeComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        sessionTypeComboBox.addActionListener(this::sessionTypeComboBoxActionPerformed);

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 51, 102));
        jLabel20.setText("Room:");

        roomComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        roomComboBox.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 51, 102));
        jLabel21.setText("Note/Reason:");

        note.setColumns(20);
        note.setRows(5);
        note.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 102)));
        jScrollPane1.setViewportView(note);

        bookAppointment.setBackground(new java.awt.Color(0, 0, 102));
        bookAppointment.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bookAppointment.setForeground(new java.awt.Color(255, 255, 255));
        bookAppointment.setText("BOOK APPOINTMENT");
        bookAppointment.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        bookAppointment.addActionListener(this::bookAppointmentActionPerformed);

        jButton4.setBackground(new java.awt.Color(0, 0, 102));
        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/back-button (1).png"))); // NOI18N
        jButton4.setText("Back");
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jPanel2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 102), 1, true));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 51, 102));
        jLabel9.setText("Tutor:");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 51, 102));
        jLabel10.setText("Subject:");

        tutorNameLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        tutorNameLabel.setForeground(new java.awt.Color(0, 51, 102));
        tutorNameLabel.setText("Laurenz Aizel Anches");

        subjectNameLabel.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        subjectNameLabel.setForeground(new java.awt.Color(0, 51, 102));
        subjectNameLabel.setText("IT Project Management");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/user (4).png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(subjectNameLabel)
                        .addGap(0, 224, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(tutorNameLabel)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(tutorNameLabel))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(subjectNameLabel)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(jLabel1)))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 51, 102));
        jLabel18.setText("Booking Details");

        timeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(0, 51, 102));

        timeStatusLabel.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        timeStatusLabel.setForeground(new java.awt.Color(0, 51, 102));
        timeStatusLabel.setText("Status");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel18))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(477, 477, 477)
                        .addComponent(jLabel22))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(142, 142, 142)
                        .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(81, 81, 81)
                        .addComponent(jLabel14))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 426, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel16)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel21))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(sessionTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(timeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(timeStatusLabel))
                                    .addComponent(roomComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(213, 213, 213)
                                .addComponent(bookAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(86, 86, 86)
                                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(68, 68, 68))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(128, 128, 128)
                        .addComponent(jLabel11)))
                .addGap(34, 34, 34))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(124, 124, 124)
                        .addComponent(jLabel11))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(26, 26, 26)
                .addComponent(jLabel18)
                .addGap(18, 18, 18)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(dateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(timeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(timeStatusLabel))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel22)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel19)
                        .addComponent(sessionTypeComboBox, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE)))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(roomComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addGap(27, 27, 27)
                .addComponent(jLabel21)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(81, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(bookAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(14, 14, 14))))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 630, 750));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void bookAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookAppointmentActionPerformed
       
        java.util.Date selectedDateValue = dateChooser.getDate();

if (selectedDateValue == null) {
    JOptionPane.showMessageDialog(this,
            "Please select a date.",
            "Booking Error",
            JOptionPane.WARNING_MESSAGE);
    return;
}

LocalDate appointmentDate = selectedDateValue.toInstant()
        .atZone(ZoneId.systemDefault())
        .toLocalDate();

String noteText = note.getText().trim();

if (timeComboBox.getSelectedItem() == null) {
    JOptionPane.showMessageDialog(this, "Please select a time.",
            "Booking Error", JOptionPane.WARNING_MESSAGE);
    return;
}

String timeStatus = timeStatusLabel.getText();

if ("Date Unavailable".equals(timeStatus)
        || "Unavailable date".equals(timeStatus)
        || "Unable to check availability".equals(timeStatus)
        || ("Booked".equals(timeStatus) && !updateMode)) {
    JOptionPane.showMessageDialog(this,
            "This date or time is unavailable. Please select another.",
            "Booking Error", JOptionPane.WARNING_MESSAGE);
    return;
}

String selectedTime = timeComboBox.getSelectedItem().toString();

String sessionType = sessionTypeComboBox.getSelectedItem() == null
        ? "" : sessionTypeComboBox.getSelectedItem().toString();

String room = "";

if ("Face-to-Face".equals(sessionType)) {
    room = roomComboBox.getSelectedItem() == null
            ? "" : roomComboBox.getSelectedItem().toString();

    if (room.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please select a room.",
                "Booking Error", JOptionPane.WARNING_MESSAGE);
        return;
    }
}

String summary =
        "Please confirm your appointment:\n\n"
        + "Tutor: " + tutorName + "\n"
        + "Subject: " + subject + "\n"
        + "Date: " + appointmentDate.format(
                DateTimeFormatter.ofPattern("MMMM d, yyyy")) + "\n"
        + "Time: " + selectedTime + "\n"
        + "Session Type: " + sessionType + "\n"
        + "Room: " + ("Online".equals(sessionType) ? "N/A" : room) + "\n"
        + "Note: " + (noteText.isEmpty() ? "None" : noteText)
        + "\n\nDo you want to "
        + (updateMode ? "save these changes?" : "confirm this appointment?");

int confirmation = JOptionPane.showConfirmDialog(
        this, summary,
        updateMode ? "Confirm Changes" : "Confirm Appointment",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE);

if (confirmation != JOptionPane.YES_OPTION) {
    return;
}

String[] times = selectedTime.split(" - ");

DateTimeFormatter formatter =
        DateTimeFormatter.ofPattern("h:mm a");

LocalTime startTime = LocalTime.parse(times[0].trim(), formatter);
LocalTime endTime = LocalTime.parse(times[1].trim(), formatter);

String findTutorSQL =
        "SELECT t.tutor_id FROM tutors t "
        + "JOIN users u ON t.user_id = u.user_id "
        + "WHERE u.full_name = ? AND t.subject = ?";

String checkSQL =
        "SELECT COUNT(*) FROM appointments "
        + "WHERE tutor_id = ? AND appointment_date = ? "
        + "AND start_time < ? AND end_time > ? "
        + "AND status IN ('Pending', 'Accepted') "
        + "AND appointment_id <> ?";

String insertSQL =
        "INSERT INTO appointments "
        + "(student_id, tutor_id, subject, appointment_date, "
        + "start_time, end_time, session_type, room, note, status) "
        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')";

String updateSQL =
        "UPDATE appointments SET tutor_id = ?, subject = ?, "
        + "appointment_date = ?, start_time = ?, end_time = ?, "
        + "session_type = ?, room = ?, note = ? "
        + "WHERE appointment_id = ? AND student_id = ? "
        + "AND status = 'Pending'";

try (Connection conn = DBConnection.getConnection()) {
    if (conn == null) {
        JOptionPane.showMessageDialog(this,
                "Cannot connect to the database.",
                "Database Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    int tutorId;

    try (PreparedStatement pst = conn.prepareStatement(findTutorSQL)) {
        pst.setString(1, tutorName);
        pst.setString(2, subject);

        try (ResultSet rs = pst.executeQuery()) {
            if (!rs.next()) {
                JOptionPane.showMessageDialog(this, "Tutor not found.",
                        "Booking Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            tutorId = rs.getInt("tutor_id");
        }
    }

    try (PreparedStatement pst = conn.prepareStatement(checkSQL)) {
        pst.setInt(1, tutorId);
        pst.setDate(2, java.sql.Date.valueOf(appointmentDate));
        pst.setTime(3, java.sql.Time.valueOf(endTime));
        pst.setTime(4, java.sql.Time.valueOf(startTime));
        pst.setInt(5, updateMode ? appointmentId : 0);

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next() && rs.getInt(1) > 0) {
                timeStatusLabel.setText("Booked");
                JOptionPane.showMessageDialog(this,
                        "This time slot is already booked. Please select another.",
                        "Time Unavailable", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }
    }

    if (updateMode) {
        try (PreparedStatement pst = conn.prepareStatement(updateSQL)) {
            pst.setInt(1, tutorId);
            pst.setString(2, subject);
            pst.setDate(3, java.sql.Date.valueOf(appointmentDate));
            pst.setTime(4, java.sql.Time.valueOf(startTime));
            pst.setTime(5, java.sql.Time.valueOf(endTime));
            pst.setString(6, sessionType);
            pst.setString(7, room);
            pst.setString(8, noteText);
            pst.setInt(9, appointmentId);
            pst.setString(10, UserSession.getStudentId());

            int updated = pst.executeUpdate();

            if (updated > 0) {
                JOptionPane.showMessageDialog(this,
                        "Appointment updated successfully!\nStatus: Pending",
                        "Update Successful", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "The appointment could not be updated. "
                        + "It may no longer be pending.",
                        "Update Failed", JOptionPane.WARNING_MESSAGE);
            }
        }
    } else {
        try (PreparedStatement pst = conn.prepareStatement(insertSQL)) {
            pst.setString(1, UserSession.getStudentId());
            pst.setInt(2, tutorId);
            pst.setString(3, subject);
            pst.setDate(4, java.sql.Date.valueOf(appointmentDate));
            pst.setTime(5, java.sql.Time.valueOf(startTime));
            pst.setTime(6, java.sql.Time.valueOf(endTime));
            pst.setString(7, sessionType);
            pst.setString(8, room);
            pst.setString(9, noteText);

            pst.executeUpdate();

            JOptionPane.showMessageDialog(this,
                    "Appointment booked successfully!\nStatus: Pending",
                    "Booking Successful", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        }
    }

} catch (SQLException e) {
    JOptionPane.showMessageDialog(this,
            (updateMode ? "Update failed: " : "Booking failed: ")
                    + e.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_bookAppointmentActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void sessionTypeComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sessionTypeComboBoxActionPerformed
       if (sessionTypeComboBox.getSelectedItem() != null) {

    String sessionType =
            sessionTypeComboBox.getSelectedItem().toString();

    if (sessionType.equals("Face-to-Face")) {

        roomComboBox.setVisible(true);

    } else {

        roomComboBox.setVisible(false);
     }
    }
    }//GEN-LAST:event_sessionTypeComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ViewAvailability().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bookAppointment;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea note;
    private javax.swing.JComboBox<String> roomComboBox;
    private javax.swing.JComboBox<String> sessionTypeComboBox;
    private javax.swing.JLabel subjectNameLabel;
    private javax.swing.JComboBox<String> timeComboBox;
    private javax.swing.JLabel timeStatusLabel;
    private javax.swing.JLabel titleDescription;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel tutorNameLabel;
    // End of variables declaration//GEN-END:variables
}
