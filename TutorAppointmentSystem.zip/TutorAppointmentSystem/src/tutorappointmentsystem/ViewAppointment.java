/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tutorappointmentsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.AbstractCellEditor;
import java.util.ArrayList;
import javax.swing.table.TableCellRenderer;
import java.awt.Color;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.FlowLayout;
import javax.swing.JPanel;

public class ViewAppointment extends javax.swing.JFrame {
    private ArrayList<Integer> appointmentIds = new ArrayList<>();
   
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ViewAppointment.class.getName());

    private DefaultTableModel originalModel;
    private java.util.List<Integer> originalAppointmentIds =
        new java.util.ArrayList<>();

    public ViewAppointment() {
        initComponents();
        setupTable();
        loadAppointments();
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        appointmentsTable.getColumnModel()
        .getColumn(4)
        .setCellRenderer(new StatusRenderer());
        appointmentsTable.setDefaultRenderer(
        Object.class, new StatusRenderer()
        
    );
    }
    
    private void loadAppointments() {

    DefaultTableModel model =
            (DefaultTableModel) appointmentsTable.getModel();

    model.setRowCount(0);
    appointmentIds.clear();

    String sql =
        "SELECT a.appointment_id, u.full_name, a.subject, "
        + "a.appointment_date, a.start_time, a.end_time, "
        + "a.session_type, a.room, a.status "
        + "FROM appointments a "
        + "JOIN tutors t ON a.tutor_id = t.tutor_id "
        + "JOIN users u ON t.user_id = u.user_id "
        + "WHERE a.student_id = ? "
        + "ORDER BY a.appointment_date, a.start_time";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, UserSession.getStudentId());

        ResultSet rs = pst.executeQuery();

        while (rs.next()) {
            
            appointmentIds.add(rs.getInt("appointment_id"));

            String tutorName =
                    rs.getString("full_name");

            String subject =
                    rs.getString("subject");

            String date =
                    rs.getDate("appointment_date").toString();

            String time =
                    rs.getTime("start_time").toString()
                    + " - "
                    + rs.getTime("end_time").toString();

            String type =
                    rs.getString("session_type");

            String room =
                    rs.getString("room");

            if (room == null || room.trim().isEmpty()) {
                room = "N/A";
            }

            String status =
                    rs.getString("status");

            String action = "";

           if (status.equalsIgnoreCase("Pending")) {
           action = "Update";
           } else {
           action = "View";
        }

           model.addRow(new Object[]{
           tutorName,
           subject,
           date,
           time,
           type,
           room,
          status,
          action
        });
        }

        rs.close();

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error loading appointments: "
                + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}


    private void setupTable() {

    appointmentsTable.getColumnModel().getColumn(0).setPreferredWidth(160);
    appointmentsTable.getColumnModel().getColumn(1).setPreferredWidth(180);
    appointmentsTable.getColumnModel().getColumn(2).setPreferredWidth(90);
    appointmentsTable.getColumnModel().getColumn(3).setPreferredWidth(140);
    appointmentsTable.getColumnModel().getColumn(4).setPreferredWidth(100);
    appointmentsTable.getColumnModel().getColumn(5).setPreferredWidth(100);
    appointmentsTable.getColumnModel().getColumn(6).setPreferredWidth(100);
    appointmentsTable.getColumnModel().getColumn(7).setPreferredWidth(200);

    appointmentsTable.getColumnModel().getColumn(7)
            .setCellRenderer(new ActionButtonRenderer());

    appointmentsTable.getColumnModel().getColumn(7)
            .setCellEditor(new ActionButtonEditor());
}
    
    private void cancelAppointment(int appointmentId) {

    String sql =
            "UPDATE appointments "
            + "SET status = 'Cancelled' "
            + "WHERE appointment_id = ? "
            + "AND student_id = ? "
            + "AND status = 'Pending'";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);
        pst.setString(2, UserSession.getStudentId());

        int updated = pst.executeUpdate();

        if (updated > 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "Appointment cancelled successfully!",
                    "Cancelled",
                    JOptionPane.INFORMATION_MESSAGE
            );

            loadAppointments();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Appointment could not be cancelled.",
                    "Cancel Error",
                    JOptionPane.WARNING_MESSAGE
            );
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error cancelling appointment: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
    private class CancelButtonEditor extends AbstractCellEditor
        implements TableCellEditor {

    private JButton button;
    private int selectedRow;

    public CancelButtonEditor() {

        button = new JButton("Cancel");

        button.setBackground(new Color(220, 38, 38));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        button.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {

                int appointmentId =
                        appointmentIds.get(selectedRow);

                int confirm = JOptionPane.showConfirmDialog(
                        ViewAppointment.this,
                        "Are you sure you want to cancel this appointment?",
                        "Cancel Appointment",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE
                );

                if (confirm == JOptionPane.YES_OPTION) {

                    cancelAppointment(appointmentId);
                }

                fireEditingStopped();
            }
        });
    }

    public Component getTableCellEditorComponent(
            JTable table,
            Object value,
            boolean isSelected,
            int row,
            int column) {

        selectedRow = row;

        return button;
    }

    public Object getCellEditorValue() {

        return "Cancel";
    }
}
    
private class StatusRenderer extends javax.swing.table.DefaultTableCellRenderer {

    @Override
    public java.awt.Component getTableCellRendererComponent(
            javax.swing.JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {

        java.awt.Component c = super.getTableCellRendererComponent(
                table, value, isSelected, hasFocus, row, column);

        String status = value == null ? "" : value.toString();

        c.setBackground(table.getBackground());
        c.setForeground(table.getForeground());

        if (status.equalsIgnoreCase("Pending")) {
            c.setBackground(new java.awt.Color(255, 204, 102));
            c.setForeground(java.awt.Color.BLACK);

        } else if (status.equalsIgnoreCase("Accepted")) {
            c.setBackground(new java.awt.Color(144, 238, 144));
            c.setForeground(java.awt.Color.BLACK);

        } else if (status.equalsIgnoreCase("Cancelled")) {
            c.setBackground(new java.awt.Color(255, 153, 153));
            c.setForeground(java.awt.Color.BLACK);

        } else if (status.equalsIgnoreCase("Declined")) {
            c.setBackground(new java.awt.Color(255, 153, 153));
            c.setForeground(java.awt.Color.BLACK);

        } else if (status.equalsIgnoreCase("Completed")) {
            c.setBackground(new java.awt.Color(144, 238, 144));
            c.setForeground(java.awt.Color.BLACK);
        }

        if (isSelected) {
            c.setBackground(table.getSelectionBackground());
            c.setForeground(table.getSelectionForeground());
        }

        return c;
    }
}

    private class ViewButtonEditor extends AbstractCellEditor
        implements TableCellEditor {

    private JButton button;
    private int selectedRow;

    public ViewButtonEditor() {
        button = new JButton("View");

        button.setBackground(new Color(37, 99, 235));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);

        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int appointmentId = appointmentIds.get(selectedRow);

                fireEditingStopped();

                viewAppointmentDetails(appointmentId);
            }
        });
    }

    @Override
    public Component getTableCellEditorComponent(
            JTable table, Object value,
            boolean isSelected, int row, int column) {

        selectedRow = table.convertRowIndexToModel(row);
        return button;
    }

    @Override
    public Object getCellEditorValue() {
        return "View";
    }
}
    private void viewAppointmentDetails(int appointmentId) {

    String sql =
            "SELECT a.*, u.full_name AS tutor_name "
            + "FROM appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "JOIN users u ON t.user_id = u.user_id "
            + "WHERE a.appointment_id = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        if (conn == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Cannot connect to the database.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        pst.setInt(1, appointmentId);

        try (ResultSet rs = pst.executeQuery()) {
            if (rs.next()) {
               
            String status = rs.getString("status");
            String declineReason = rs.getString("decline_reason");

            if (declineReason == null || declineReason.trim().isEmpty()) {
            declineReason = "No decline reason provided.";
        }

            String details =
                "Tutor: " + rs.getString("tutor_name")
                + "\nSubject: " + rs.getString("subject")
                + "\nDate: " + rs.getDate("appointment_date")
                + "\nTime: " + rs.getTime("start_time")
                + " - " + rs.getTime("end_time")
                + "\nSession Type: " + rs.getString("session_type")
                + "\nRoom: " + rs.getString("room")
                + "\nNote: " + rs.getString("note")
                + "\nStatus: " + status;

                if ("Declined".equalsIgnoreCase(status)) {
                details += "\nTutor's Decline Reason: " + declineReason;
        }


                JOptionPane.showMessageDialog(
                        this,
                        details,
                        "Appointment Details",
                        JOptionPane.INFORMATION_MESSAGE
                );
            } else {
                JOptionPane.showMessageDialog(
                        this,
                        "Appointment not found.",
                        "View Appointment",
                        JOptionPane.WARNING_MESSAGE
                );
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Unable to load appointment details: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
    
    saveOriginalAppointments();
}
    

private class ActionButtonEditor extends AbstractCellEditor
        implements TableCellEditor {

    private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));
    private final JButton updateButton = new JButton("Update");
    private final JButton cancelButton = new JButton("Cancel");
    private final JButton viewButton = new JButton("View");

    private int selectedRow;

    public ActionButtonEditor() {
        updateButton.setBackground(new Color(22, 163, 74));
        cancelButton.setBackground(new Color(220, 38, 38));
        viewButton.setBackground(new Color(37, 99, 235));

        updateButton.setForeground(Color.WHITE);
        cancelButton.setForeground(Color.WHITE);
        viewButton.setForeground(Color.WHITE);

        updateButton.setFocusPainted(false);
        cancelButton.setFocusPainted(false);
        viewButton.setFocusPainted(false);

        updateButton.addActionListener(e -> {
            int modelRow = appointmentsTable.convertRowIndexToModel(selectedRow);
            int appointmentId = appointmentIds.get(modelRow);

            String tutorName = appointmentsTable.getModel()
                    .getValueAt(modelRow, 0).toString();

            String subject = appointmentsTable.getModel()
                    .getValueAt(modelRow, 1).toString();

            String status = appointmentsTable.getModel()
                    .getValueAt(modelRow, 6).toString();

            fireEditingStopped();

            if (!"Pending".equalsIgnoreCase(status)) {
                JOptionPane.showMessageDialog(
                        ViewAppointment.this,
                        "Only pending appointments can be updated.",
                        "Update Appointment",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            ViewAvailability form =
                    new ViewAvailability(appointmentId, tutorName, subject);
            form.setVisible(true);
            
        });

        cancelButton.addActionListener(e -> {
            int modelRow = appointmentsTable.convertRowIndexToModel(selectedRow);
            int appointmentId = appointmentIds.get(modelRow);

            fireEditingStopped();

            int confirm = JOptionPane.showConfirmDialog(
                    ViewAppointment.this,
                    "Are you sure you want to cancel this appointment?",
                    "Cancel Appointment",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (confirm == JOptionPane.YES_OPTION) {
                cancelAppointment(appointmentId);
            }
        });

        viewButton.addActionListener(e -> {
            int modelRow = appointmentsTable.convertRowIndexToModel(selectedRow);
            int appointmentId = appointmentIds.get(modelRow);

            fireEditingStopped();
            viewAppointmentDetails(appointmentId);
        });

        panel.setOpaque(true);
    }

    @Override
    public Component getTableCellEditorComponent(
            JTable table, Object value,
            boolean isSelected, int row, int column) {

        selectedRow = row;
        panel.removeAll();

        int modelRow = table.convertRowIndexToModel(row);
        String status = table.getModel().getValueAt(modelRow, 6).toString();

        if ("Pending".equalsIgnoreCase(status)) {
            panel.add(updateButton);
            panel.add(cancelButton);
        } else {
            panel.add(viewButton);
        }

        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return "";
    }
}
    private class ActionButtonRenderer implements TableCellRenderer {

    private final JPanel panel =
            new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));

    private final JButton updateButton = new JButton("Update");
    private final JButton cancelButton = new JButton("Cancel");
    private final JButton viewButton = new JButton("View");

    public ActionButtonRenderer() {
        updateButton.setBackground(new Color(22, 163, 74));
        cancelButton.setBackground(new Color(220, 38, 38));
        viewButton.setBackground(new Color(37, 99, 235));

        updateButton.setForeground(Color.WHITE);
        cancelButton.setForeground(Color.WHITE);
        viewButton.setForeground(Color.WHITE);

        updateButton.setFocusPainted(false);
        cancelButton.setFocusPainted(false);
        viewButton.setFocusPainted(false);

        panel.setOpaque(true);
    }

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected,
            boolean hasFocus, int row, int column) {

        panel.removeAll();

        int modelRow = table.convertRowIndexToModel(row);
        String status = String.valueOf(
                table.getModel().getValueAt(modelRow, 6)
        );

        if ("Pending".equalsIgnoreCase(status)) {
            panel.add(updateButton);
            panel.add(cancelButton);
        } else {
            panel.add(viewButton);
        }

        viewButton.setBackground(new Color(37, 99, 235));

        panel.setBackground(isSelected
                ? table.getSelectionBackground()
                : table.getBackground());

        panel.revalidate();
        panel.repaint();

        return panel;
    }
}


    private void filterAppointments() {

    DefaultTableModel model =
            (DefaultTableModel) appointmentsTable.getModel();

    model.setRowCount(0);
    appointmentIds.clear();

    String search = searchField.getText().trim();

    Object selectedItem = sortComboBox.getSelectedItem();

    String selectedStatus = selectedItem == null
            ? "All" : selectedItem.toString().trim();

    String sql =
        "SELECT a.appointment_id, u.full_name, a.subject, "
        + "a.appointment_date, a.start_time, a.end_time, "
        + "a.session_type, a.room, a.status "
        + "FROM appointments a "
        + "JOIN tutors t ON a.tutor_id = t.tutor_id "
        + "JOIN users u ON t.user_id = u.user_id "
        + "WHERE a.student_id = ? "
        + "AND (LOWER(u.full_name) LIKE ? "
        + "OR LOWER(a.subject) LIKE ?) "
        + "AND (? = 'All' OR LOWER(a.status) = LOWER(?)) "
        + "ORDER BY a.appointment_date, a.start_time";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, UserSession.getStudentId());
        pst.setString(2, "%" + search.toLowerCase() + "%");
        pst.setString(3, "%" + search.toLowerCase() + "%");
        pst.setString(4, selectedStatus);
        pst.setString(5, selectedStatus);

        try (ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {

                int appointmentId = rs.getInt("appointment_id");

                String tutorName = rs.getString("full_name");
                String subject = rs.getString("subject");
                String date = rs.getDate("appointment_date").toString();

                String time =
                        rs.getTime("start_time").toString()
                        + " - "
                        + rs.getTime("end_time").toString();

                String type = rs.getString("session_type");
                String room = rs.getString("room");

                if (room == null || room.trim().isEmpty()) {
                    room = "N/A";
                }

                String status = rs.getString("status");

                String action =
                        status.equalsIgnoreCase("Pending")
                        ? "Update" : "View";

                model.addRow(new Object[]{
                    tutorName, subject, date, time,
                    type, room, status, action
                });

                appointmentIds.add(appointmentId);
            }
        }

    } catch (SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Error filtering appointments: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void saveOriginalAppointments() {

    DefaultTableModel model =
            (DefaultTableModel) appointmentsTable.getModel();

    originalModel = new DefaultTableModel(
            new Object[]{"Tutor", "Subject", "Date", "Time",
                "Type", "Room", "Status", "Action"}, 0);

    originalAppointmentIds.clear();

    for (int i = 0; i < model.getRowCount(); i++) {

        Object[] row = new Object[model.getColumnCount()];

        for (int col = 0; col < model.getColumnCount(); col++) {
            row[col] = model.getValueAt(i, col);
        }

        originalModel.addRow(row);
        originalAppointmentIds.add(appointmentIds.get(i));
    }
}




    



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        home = new javax.swing.JButton();
        tutorList = new javax.swing.JButton();
        viewAppointment = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        profile = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        appointmentsTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        sortComboBox = new javax.swing.JComboBox<>();
        searchButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jPanel4.setBackground(new java.awt.Color(51, 0, 153));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        home.setBackground(new java.awt.Color(0, 0, 153));
        home.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/dashboard.png"))); // NOI18N
        home.setText("DASHBOARD");
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        home.addActionListener(this::homeActionPerformed);

        tutorList.setBackground(new java.awt.Color(0, 0, 153));
        tutorList.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        tutorList.setForeground(new java.awt.Color(242, 242, 242));
        tutorList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/multiple-users-silhouette.png"))); // NOI18N
        tutorList.setText("VIEW AVAILABLE TUTOR");
        tutorList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tutorList.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tutorList.addActionListener(this::tutorListActionPerformed);

        viewAppointment.setBackground(new java.awt.Color(0, 0, 153));
        viewAppointment.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        viewAppointment.setForeground(new java.awt.Color(242, 242, 242));
        viewAppointment.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/clipboard.png"))); // NOI18N
        viewAppointment.setText("VIEW APPOINTMENT");
        viewAppointment.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        viewAppointment.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        viewAppointment.addActionListener(this::viewAppointmentActionPerformed);

        logout.setBackground(new java.awt.Color(0, 0, 153));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(242, 242, 242));
        logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/logout.png"))); // NOI18N
        logout.setText("LOGOUT");
        logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/CITE Logo (2) (3).png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("CITE Tutor Appointment");

        profile.setBackground(new java.awt.Color(0, 0, 153));
        profile.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        profile.setForeground(new java.awt.Color(242, 242, 242));
        profile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/user.png"))); // NOI18N
        profile.setText("PROFILE");
        profile.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        profile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        profile.addActionListener(this::profileActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(viewAppointment, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(tutorList, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(home, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(profile, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jLabel5)
                .addContainerGap(59, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addGap(38, 38, 38)
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(tutorList, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(viewAppointment, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(profile, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 174, Short.MAX_VALUE)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
        );

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("MY APPOINTMENT");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(392, 392, 392))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel3)
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 51, 102));
        jLabel4.setText("APPOINTMENTS");

        appointmentsTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        appointmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Tutor", "Subject", "Date", "Time", "Type", "Room", "Status", "Action"
            }
        ));
        appointmentsTable.setGridColor(new java.awt.Color(0, 0, 0));
        appointmentsTable.setRowHeight(40);
        appointmentsTable.setSelectionBackground(new java.awt.Color(102, 102, 102));
        appointmentsTable.setShowGrid(true);
        jScrollPane1.setViewportView(appointmentsTable);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 51, 102));
        jLabel7.setText("Search:");

        searchField.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        searchField.addActionListener(this::searchFieldActionPerformed);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 51, 102));
        jLabel8.setText("Sort By:");

        sortComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Pending", "Accepted", "Cancelled", "Declined", "Completed" }));
        sortComboBox.addActionListener(this::sortComboBoxActionPerformed);

        searchButton.setBackground(new java.awt.Color(0, 0, 102));
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/magnifying-glass.png"))); // NOI18N
        searchButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchButton.addActionListener(this::searchButtonActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(jLabel4)
                        .addGap(602, 816, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 355, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(sortComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel4)
                .addGap(73, 73, 73)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8)
                    .addComponent(sortComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 272, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 850));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        Home home = new Home();
        home.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed

    private void tutorListActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tutorListActionPerformed
        TutorList tutorList = new TutorList();
        tutorList.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_tutorListActionPerformed

    private void viewAppointmentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewAppointmentActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_viewAppointmentActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {

            UserSession.clearSession();

            Login login = new Login();
            login.setVisible(true);
            this.dispose();
        }
    }//GEN-LAST:event_logoutActionPerformed

    private void profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileActionPerformed
        StudentProfile profile = new StudentProfile();
        profile.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_profileActionPerformed

    private void searchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchFieldActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        filterAppointments();
    }//GEN-LAST:event_searchButtonActionPerformed

    private void sortComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortComboBoxActionPerformed
        filterAppointments();
    }//GEN-LAST:event_sortComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ViewAppointment().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable appointmentsTable;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    private javax.swing.JButton profile;
    private javax.swing.JButton searchButton;
    private javax.swing.JTextField searchField;
    private javax.swing.JComboBox<String> sortComboBox;
    private javax.swing.JButton tutorList;
    private javax.swing.JButton viewAppointment;
    // End of variables declaration//GEN-END:variables
}
