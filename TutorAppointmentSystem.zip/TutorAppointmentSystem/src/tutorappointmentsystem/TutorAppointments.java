/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tutorappointmentsystem;


import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractCellEditor;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;


public class TutorAppointments extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TutorAppointments.class.getName());

    
private final List<Integer> appointmentIds = new ArrayList<>();


    
    public TutorAppointments() {
        initComponents();
        loadAppointments();
        setupActionColumn();
        setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        searchButton.addActionListener(e -> loadAppointments());
        sortComboBox.addActionListener(e -> loadAppointments());
    }
    
    
    
private void loadAppointments() {
    DefaultTableModel model =
            (DefaultTableModel) appointmentsTable.getModel();

    model.setRowCount(0);
    appointmentIds.clear();

    String selectedStatus = sortComboBox.getSelectedItem() != null
            ? sortComboBox.getSelectedItem().toString()
            : "All";

    String searchText = "%" + searchField.getText().trim() + "%";

    String sql =
            "SELECT a.appointment_id, u.full_name, a.subject, "
            + "a.appointment_date, a.start_time, a.end_time, "
            + "a.session_type, a.room, a.note, a.status "
            + "FROM appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "JOIN users u ON a.student_id = u.student_id "
            + "WHERE t.user_id = ? "
            + "AND (? = 'All' OR LOWER(a.status) = LOWER(?)) "
            + "AND (u.full_name LIKE ? OR a.subject LIKE ?) "
            + "ORDER BY a.appointment_date, a.start_time";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, UserSession.getUserId());
        pst.setString(2, selectedStatus);
        pst.setString(3, selectedStatus);
        pst.setString(4, searchText);
        pst.setString(5, searchText);

        try (ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {

                int appointmentId = rs.getInt("appointment_id");
                appointmentIds.add(appointmentId);

                String studentName = rs.getString("full_name");
                String subject = rs.getString("subject");

                String date = rs.getDate("appointment_date") != null
                        ? rs.getDate("appointment_date").toString()
                        : "";

                String startTime = rs.getTime("start_time") != null
                        ? rs.getTime("start_time").toString()
                        : "";

                String endTime = rs.getTime("end_time") != null
                        ? rs.getTime("end_time").toString()
                        : "";

                String time = startTime + " - " + endTime;

                String type = rs.getString("session_type");

                String room = rs.getString("room");
                if (room == null || room.trim().isEmpty()) {
                    room = "N/A";
                }

                String note = rs.getString("note");
                if (note == null || note.trim().isEmpty()) {
                    note = "N/A";
                }

                String status = rs.getString("status");

                model.addRow(new Object[]{
                    studentName,
                    subject,
                    date,
                    time,
                    type,
                    room,
                    note,
                    status,
                    ""
                });
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
                this,
                "Error loading appointments: " + e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}

    private void setupActionColumn() {
    appointmentsTable.getColumnModel()
            .getColumn(8)
            .setCellRenderer(new ActionButtonRenderer());

    appointmentsTable.getColumnModel()
            .getColumn(8)
            .setCellEditor(new ActionButtonEditor());

    appointmentsTable.getColumnModel()
            .getColumn(8)
            .setPreferredWidth(190);

    appointmentsTable.setRowHeight(40);

}
    
private class ActionButtonEditor extends AbstractCellEditor
        implements TableCellEditor {

    private final JPanel panel =
            new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 2));

    private final JButton acceptButton = new JButton("Accept");
    private final JButton declineButton = new JButton("Decline");
    private final JButton viewButton = new JButton("View");
    private final JButton completeButton = new JButton("Complete");

    private int selectedRow;

    public ActionButtonEditor() {
        acceptButton.setBackground(new Color(22, 163, 74));
        declineButton.setBackground(new Color(220, 38, 38));
        viewButton.setBackground(new Color(37, 99, 235));
        completeButton.setBackground(new Color(124, 58, 237));

        acceptButton.setForeground(Color.WHITE);
        declineButton.setForeground(Color.WHITE);
        viewButton.setForeground(Color.WHITE);
        completeButton.setForeground(Color.WHITE);

        acceptButton.setFocusPainted(false);
        declineButton.setFocusPainted(false);
        viewButton.setFocusPainted(false);
        completeButton.setFocusPainted(false);

        acceptButton.addActionListener(e -> {
            fireEditingStopped();
            changeAppointmentStatus("Accepted");
        });

       
        declineButton.addActionListener(e -> {
            JTextArea reasonArea = new JTextArea(4, 25);
            reasonArea.setLineWrap(true);
            reasonArea.setWrapStyleWord(true);

        int result = JOptionPane.showConfirmDialog(
            TutorAppointments.this,
            new JScrollPane(reasonArea),
            "Enter Reason for Declining",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (result != JOptionPane.OK_OPTION) {
        return;
        }

        String reason = reasonArea.getText().trim();

        if (reason.isEmpty()) {
            JOptionPane.showMessageDialog(
                TutorAppointments.this,
                "Please enter a reason before declining.",
                "Reason Required",
                JOptionPane.WARNING_MESSAGE
        );
        return;
        }

        int row = appointmentsTable.getSelectedRow();

        if (row == -1) {
        return;
        }

        int modelRow = appointmentsTable.convertRowIndexToModel(row);
        int appointmentId = appointmentIds.get(modelRow);

        fireEditingStopped();
        declineAppointment(appointmentId, reason);
    });

        viewButton.addActionListener(e -> {
            fireEditingStopped();

            int viewRow = appointmentsTable.getSelectedRow();

            if (viewRow == -1) {
                JOptionPane.showMessageDialog(
                        TutorAppointments.this,
                        "Please select an appointment first.",
                        "No Appointment Selected",
                        JOptionPane.WARNING_MESSAGE
                );
                return;
            }

            int modelRow =
                    appointmentsTable.convertRowIndexToModel(viewRow);

            String student = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 0));
            String subject = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 1));
            String date = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 2));
            String time = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 3));
            String type = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 4));
            String room = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 5));
            String note = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 6));
            String status = String.valueOf(
                    appointmentsTable.getModel().getValueAt(modelRow, 7));

            String details =
                    "Student: " + student
                    + "\nSubject: " + subject
                    + "\nDate: " + date
                    + "\nTime: " + time
                    + "\nSession Type: " + type
                    + "\nRoom: " + room
                    + "\nNote/Reason: " + note
                    + "\nStatus: " + status;

            JOptionPane.showMessageDialog(
                    TutorAppointments.this,
                    details,
                    "Appointment Details",
                    JOptionPane.INFORMATION_MESSAGE
            );
        });

        completeButton.addActionListener(e -> {
            int viewRow = appointmentsTable.getSelectedRow();

            if (viewRow == -1) {
                fireEditingCanceled();
                return;
            }

            int modelRow =
                    appointmentsTable.convertRowIndexToModel(viewRow);

            int appointmentId = appointmentIds.get(modelRow);

            int confirm = JOptionPane.showConfirmDialog(
                    TutorAppointments.this,
                    "Mark this appointment as completed?",
                    "Confirm Completion",
                    JOptionPane.YES_NO_OPTION
            );

            if (confirm == JOptionPane.YES_OPTION) {
                fireEditingStopped();
                completeAppointment(appointmentId);
            } else {
                fireEditingCanceled();
            }
        });

        panel.setOpaque(true);
    }

    @Override
    public Component getTableCellEditorComponent(
            JTable table, Object value,
            boolean isSelected, int row, int column) {

        selectedRow = row;
        panel.removeAll();

        int modelRow = table.convertRowIndexToModel(row);

        String status = String.valueOf(
                table.getModel().getValueAt(modelRow, 7));

        if ("Pending".equalsIgnoreCase(status)) {
            panel.add(acceptButton);
            panel.add(declineButton);

        } else if ("Accepted".equalsIgnoreCase(status)) {
            panel.add(completeButton);
            panel.add(viewButton);

        } else {
            panel.add(viewButton);
        }

        panel.revalidate();
        panel.repaint();

        return panel;
    }

    @Override
    public Object getCellEditorValue() {
        return "";
    }
}

    class ActionButtonRenderer extends JPanel implements javax.swing.table.TableCellRenderer {

    private final JButton acceptButton = new JButton("Accept");
    private final JButton declineButton = new JButton("Decline");
    private final JButton completeButton = new JButton("Complete");
    private final JButton viewButton = new JButton("View");

    public ActionButtonRenderer() {
        setLayout(new FlowLayout(FlowLayout.CENTER, 3, 2));

        add(acceptButton);
        add(declineButton);
        add(completeButton);
        add(viewButton);

        acceptButton.setBackground(new Color(46, 125, 50));
        acceptButton.setForeground(Color.WHITE);

        declineButton.setBackground(new Color(198, 40, 40));
        declineButton.setForeground(Color.WHITE);

        completeButton.setBackground(new Color(21, 101, 192));
        completeButton.setForeground(Color.WHITE);

        viewButton.setBackground(new Color(21, 101, 192));
        viewButton.setForeground(Color.WHITE);
    }

    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected,
            boolean hasFocus, int row, int column) {

        int modelRow = table.convertRowIndexToModel(row);
        String status = table.getModel().getValueAt(modelRow, 7).toString();

        acceptButton.setVisible("Pending".equalsIgnoreCase(status));
        declineButton.setVisible("Pending".equalsIgnoreCase(status));

        completeButton.setVisible("Accepted".equalsIgnoreCase(status));

        viewButton.setVisible(
                !"Pending".equalsIgnoreCase(status)
        );

        if (isSelected) {
            setBackground(table.getSelectionBackground());
        } else {
            setBackground(table.getBackground());
        }

        return this;
    }
}

    
private void changeAppointmentStatus(String newStatus) {
    int row = appointmentsTable.getSelectedRow();

    if (row == -1) {
        JOptionPane.showMessageDialog(this, "Please select an appointment.");
        return;
    }

    int modelRow = appointmentsTable.convertRowIndexToModel(row);
    int appointmentId = appointmentIds.get(modelRow);

    String sql = "UPDATE appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "SET a.status = ? "
            + "WHERE a.appointment_id = ? "
            + "AND t.user_id = ? "
            + "AND a.status = 'Pending'";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, newStatus);
        pst.setInt(2, appointmentId);
        pst.setInt(3, UserSession.getUserId());

        int updated = pst.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(this,
                    "Appointment " + newStatus.toLowerCase() + " successfully!");
            loadAppointments();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Appointment could not be updated.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}
    
private void completeAppointment(int appointmentId) {
    String sql = "UPDATE appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "SET a.status = 'Completed' "
            + "WHERE a.appointment_id = ? "
            + "AND t.user_id = ? "
            + "AND a.status = 'Accepted'";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setInt(1, appointmentId);
        pst.setInt(2, UserSession.getUserId());

        int updated = pst.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(this,
                    "Appointment marked as completed!");
            loadAppointments();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Appointment could not be completed.");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, e.getMessage());
    }
}
    
private void declineAppointment(int appointmentId, String reason) {
    String sql = "UPDATE appointments a "
            + "JOIN tutors t ON a.tutor_id = t.tutor_id "
            + "SET a.status = 'Declined', a.decline_reason = ? "
            + "WHERE a.appointment_id = ? "
            + "AND t.user_id = ? "
            + "AND a.status = 'Pending'";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        pst.setString(1, reason);
        pst.setInt(2, appointmentId);
        pst.setInt(3, UserSession.getUserId());

        int updated = pst.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(
                    this, "Appointment declined successfully!"
            );
            loadAppointments();
        } else {
            JOptionPane.showMessageDialog(
                    this, "Appointment could not be declined."
            );
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, ex.getMessage());
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        home = new javax.swing.JButton();
        appointments = new javax.swing.JButton();
        profile = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        appointmentsTable = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        sortComboBox = new javax.swing.JComboBox<>();
        searchButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jPanel2.setBackground(new java.awt.Color(51, 0, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/CITE Logo (2) (3).png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("CITE Tutor Appointment");

        home.setBackground(new java.awt.Color(0, 0, 153));
        home.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        home.setForeground(new java.awt.Color(255, 255, 255));
        home.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/dashboard.png"))); // NOI18N
        home.setText("DASHBOARD");
        home.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        home.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        home.addActionListener(this::homeActionPerformed);

        appointments.setBackground(new java.awt.Color(0, 0, 153));
        appointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        appointments.setForeground(new java.awt.Color(255, 255, 255));
        appointments.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/calendar.png"))); // NOI18N
        appointments.setText("APPOINTMENTS");
        appointments.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        appointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        appointments.addActionListener(this::appointmentsActionPerformed);

        profile.setBackground(new java.awt.Color(0, 0, 153));
        profile.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        profile.setForeground(new java.awt.Color(255, 255, 255));
        profile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/user.png"))); // NOI18N
        profile.setText("PROFILE");
        profile.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        profile.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        profile.addActionListener(this::profileActionPerformed);

        logout.setBackground(new java.awt.Color(0, 0, 153));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(255, 255, 255));
        logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/logout.png"))); // NOI18N
        logout.setText("LOGOUT");
        logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logout.addActionListener(this::logoutActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(profile, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(appointments, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(home, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(115, 115, 115)
                                .addComponent(jLabel1))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(87, 87, 87)
                                .addComponent(jLabel8)))
                        .addGap(0, 84, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(42, 42, 42)
                .addComponent(home, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(appointments, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(profile, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("MANAGE APPOINTMENTS");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(275, 275, 275))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel3)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        appointmentsTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        appointmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Student Name", "Subject", "Date", "Time", "Type", "Room", "Note/Reason", "Status", "Action"
            }
        ));
        appointmentsTable.setGridColor(new java.awt.Color(0, 0, 0));
        appointmentsTable.setRowHeight(40);
        appointmentsTable.setSelectionBackground(new java.awt.Color(102, 102, 102));
        appointmentsTable.setShowGrid(true);
        jScrollPane1.setViewportView(appointmentsTable);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Appointment Requests");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 102));
        jLabel4.setText("Sort By:");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Search:");

        sortComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Pending", "Accepted", "Declined", "Completed" }));
        sortComboBox.addActionListener(this::sortComboBoxActionPerformed);

        searchButton.setBackground(new java.awt.Color(0, 0, 102));
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/magnifying-glass.png"))); // NOI18N
        searchButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchButton.addActionListener(this::searchButtonActionPerformed);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 2, Short.MAX_VALUE)
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 297, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27)
                        .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(526, 526, 526))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(sortComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(750, 750, 750))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel2)
                .addGap(51, 51, 51)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(sortComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(166, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, 850));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void appointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_appointmentsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_appointmentsActionPerformed

    private void profileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_profileActionPerformed
        TutorProfile tutorProfile = new TutorProfile();
        tutorProfile.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_profileActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to logout?",
        "Confirm Logout",
        JOptionPane.YES_NO_OPTION
    );

    if (choice == JOptionPane.YES_OPTION) {

        UserSession.clearSession();

        Login login = new Login();
        login.setVisible(true);
        this.dispose();
      }
    }//GEN-LAST:event_logoutActionPerformed

    private void homeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_homeActionPerformed
        TutorHome tutorHome = new TutorHome();
        tutorHome.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_homeActionPerformed

    private void sortComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sortComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sortComboBoxActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TutorAppointments().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton appointments;
    private javax.swing.JTable appointmentsTable;
    private javax.swing.JButton home;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    private javax.swing.JButton profile;
    private javax.swing.JButton searchButton;
    private javax.swing.JTextField searchField;
    private javax.swing.JComboBox<String> sortComboBox;
    // End of variables declaration//GEN-END:variables
}
