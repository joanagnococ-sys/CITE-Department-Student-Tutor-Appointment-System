/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package tutorappointmentsystem;

import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class ManageAccounts extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(ManageAccounts.class.getName());

    /**
     * Creates new form ManageAccounts
     */
    public ManageAccounts() {
         initComponents();
         setupRoleFilter();
         setupStatusFilter();
         loadAccounts();
         setupAccountButtonColumn();
         setupAccountStatusColors();
         setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
    }
    
        
private void loadAccounts() {
    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) accountsTable.getModel();

    model.setRowCount(0);

    String sql = "SELECT user_id, " +
            "full_name, email, role, account_status " +
            "FROM users " +
            "ORDER BY user_id ASC";

    try (java.sql.Connection con = DBConnection.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql);
         java.sql.ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getInt("user_id"),
                rs.getString("full_name"),
                rs.getString("email"),
                rs.getString("role"),
                rs.getString("account_status"),
                "Manage"
            });
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Unable to load accounts: " + e.getMessage(),
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
}

    
private void setupRoleFilter() {
    roleComboBox.removeAllItems();

    roleComboBox.addItem("All Roles");
    roleComboBox.addItem("Student");
    roleComboBox.addItem("Tutor");
    roleComboBox.addItem("Admin");

    roleComboBox.setSelectedIndex(0);

    roleComboBox.addActionListener(e -> filterAccountsByRole());
}

    
private void filterAccountsByRole() {
    String selectedRole = (String) roleComboBox.getSelectedItem();

    if (selectedRole == null || selectedRole.equals("All Roles")) {
        loadAccounts();
        return;
    }

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) accountsTable.getModel();

    model.setRowCount(0);

    String sql = "SELECT user_id, full_name, email, role, account_status " +
            "FROM users WHERE role = ? ORDER BY user_id ASC";

    try (java.sql.Connection con = DBConnection.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, selectedRole);

        try (java.sql.ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("role"),
                    rs.getString("account_status"),
                    "Manage"
                });
            }
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Unable to filter accounts: " + e.getMessage(),
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
}

    
private void setupStatusFilter() {
    statusComboBox.removeAllItems();

    statusComboBox.addItem("All Status");
    statusComboBox.addItem("Active");
    statusComboBox.addItem("Inactive");

    statusComboBox.setSelectedIndex(0);

    statusComboBox.addActionListener(e -> filterAccountsByStatus());
}

    
private void filterAccountsByStatus() {
    String selectedStatus = (String) statusComboBox.getSelectedItem();

    if (selectedStatus == null || selectedStatus.equals("All Status")) {
        loadAccounts();
        return;
    }

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) accountsTable.getModel();

    model.setRowCount(0);

    String sql = "SELECT user_id, full_name, email, role, account_status " +
            "FROM users WHERE account_status = ? ORDER BY user_id ASC";

    try (java.sql.Connection con = DBConnection.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql)) {

        pst.setString(1, selectedStatus);

        try (java.sql.ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("role"),
                    rs.getString("account_status"),
                    "Manage"
                });
            }
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Unable to filter accounts: " + e.getMessage(),
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
}

    
private class AccountButtonRenderer extends javax.swing.JButton
        implements javax.swing.table.TableCellRenderer {

    public AccountButtonRenderer() {
        setOpaque(true);
        setFocusPainted(false);
        setForeground(java.awt.Color.WHITE);
    }

    @Override
    public java.awt.Component getTableCellRendererComponent(
            javax.swing.JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {

        int modelRow = table.convertRowIndexToModel(row);
        String status = table.getModel()
                .getValueAt(modelRow, 4).toString();

        if (status.equalsIgnoreCase("Active")) {
            setText("Deactivate");
            setBackground(new java.awt.Color(220, 38, 38)); 
        } else {
            setText("Activate");
            setBackground(new java.awt.Color(22, 163, 74)); 
        }

        return this;
    }
}

    
private void setupAccountButtonColumn() {
    int actionColumn = 5; 

    accountsTable.getColumnModel()
            .getColumn(actionColumn)
            .setCellRenderer(new AccountButtonRenderer());

    accountsTable.getColumnModel()
            .getColumn(actionColumn)
            .setCellEditor(new AccountButtonEditor());
}

    
private class AccountButtonEditor
        extends javax.swing.AbstractCellEditor
        implements javax.swing.table.TableCellEditor {

    private final javax.swing.JButton button;
    private int userId;
    private String currentStatus;

    public AccountButtonEditor() {
        button = new javax.swing.JButton();
        button.setOpaque(true);
        button.setForeground(java.awt.Color.WHITE);
        button.setFocusPainted(false);

        button.addActionListener(e -> {
            fireEditingStopped();

            int confirm = javax.swing.JOptionPane.showConfirmDialog(
                    ManageAccounts.this,
                    "Are you sure you want to " +
                    (currentStatus.equalsIgnoreCase("Active")
                            ? "deactivate" : "activate") +
                    " this account?",
                    "Confirm Account Status",
                    javax.swing.JOptionPane.YES_NO_OPTION
            );

            if (confirm == javax.swing.JOptionPane.YES_OPTION) {
                updateAccountStatus();
            }
        });
    }

    @Override
    public java.awt.Component getTableCellEditorComponent(
            javax.swing.JTable table, Object value,
            boolean isSelected, int row, int column) {

        int modelRow = table.convertRowIndexToModel(row);

        userId = Integer.parseInt(
                table.getModel().getValueAt(modelRow, 0).toString()
        );

        currentStatus = table.getModel()
                .getValueAt(modelRow, 4).toString();

        if (currentStatus.equalsIgnoreCase("Active")) {
            button.setText("Deactivate");
            button.setBackground(new java.awt.Color(220, 38, 38));
        } else {
            button.setText("Activate");
            button.setBackground(new java.awt.Color(22, 163, 74));
        }

        return button;
    }

    @Override
    public Object getCellEditorValue() {
        return button.getText();
    }

    private void updateAccountStatus() {
        String newStatus = currentStatus.equalsIgnoreCase("Active")
                ? "Inactive" : "Active";

        String sql = "UPDATE users SET account_status = ? WHERE user_id = ?";

        try (java.sql.Connection con = DBConnection.getConnection();
             java.sql.PreparedStatement pst = con.prepareStatement(sql)) {

            pst.setString(1, newStatus);
            pst.setInt(2, userId);

            int updated = pst.executeUpdate();

            if (updated > 0) {
                javax.swing.JOptionPane.showMessageDialog(
                        ManageAccounts.this,
                        "Account status changed to " + newStatus + "."
                );

                loadAccounts();
            }

        } catch (java.sql.SQLException ex) {
            javax.swing.JOptionPane.showMessageDialog(
                    ManageAccounts.this,
                    "Unable to update account: " + ex.getMessage(),
                    "Database Error",
                    javax.swing.JOptionPane.ERROR_MESSAGE
            );
        }
    }
}

    
private void setupAccountStatusColors() {
    accountsTable.getColumnModel()
            .getColumn(4)
            .setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {

        @Override
        public java.awt.Component getTableCellRendererComponent(
                javax.swing.JTable table,
                Object value,
                boolean isSelected,
                boolean hasFocus,
                int row,
                int column) {

            java.awt.Component component =
                    super.getTableCellRendererComponent(
                            table, value, isSelected, hasFocus, row, column
                    );

            String status = value == null ? "" : value.toString().trim();

            if (isSelected) {
                return component;
            }

            if (status.equalsIgnoreCase("Active")) {
                component.setBackground(new java.awt.Color(22, 163, 74));
                component.setForeground(java.awt.Color.WHITE);
            } else if (status.equalsIgnoreCase("Inactive")) {
                component.setBackground(new java.awt.Color(220, 38, 38));
                component.setForeground(java.awt.Color.WHITE);
            } else {
                component.setBackground(table.getBackground());
                component.setForeground(table.getForeground());
            }

            return component;
        }
    });
}








    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        adminHome = new javax.swing.JButton();
        manageTutors = new javax.swing.JButton();
        manageAppointments = new javax.swing.JButton();
        manageAccounts = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        searchField = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        roleComboBox = new javax.swing.JComboBox<>();
        jLabel12 = new javax.swing.JLabel();
        statusComboBox = new javax.swing.JComboBox<>();
        refreshButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        accountsTable = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jPanel2.setBackground(new java.awt.Color(51, 0, 153));
        jPanel2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/CITE Logo (2) (3).png"))); // NOI18N

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("CITE Tutor Appointment");

        adminHome.setBackground(new java.awt.Color(0, 0, 153));
        adminHome.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        adminHome.setForeground(new java.awt.Color(242, 242, 242));
        adminHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/dashboard.png"))); // NOI18N
        adminHome.setText("DASHBOARD");
        adminHome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        adminHome.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        adminHome.addActionListener(this::adminHomeActionPerformed);

        manageTutors.setBackground(new java.awt.Color(0, 0, 153));
        manageTutors.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        manageTutors.setForeground(new java.awt.Color(242, 242, 242));
        manageTutors.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/multiple-users-silhouette.png"))); // NOI18N
        manageTutors.setText("MANAGE TUTORS");
        manageTutors.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        manageTutors.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manageTutors.addActionListener(this::manageTutorsActionPerformed);

        manageAppointments.setBackground(new java.awt.Color(0, 0, 153));
        manageAppointments.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        manageAppointments.setForeground(new java.awt.Color(242, 242, 242));
        manageAppointments.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/clipboard.png"))); // NOI18N
        manageAppointments.setText("MANAGE APPOINTMENTS");
        manageAppointments.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        manageAppointments.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        manageAppointments.addActionListener(this::manageAppointmentsActionPerformed);

        manageAccounts.setBackground(new java.awt.Color(0, 0, 153));
        manageAccounts.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        manageAccounts.setForeground(new java.awt.Color(242, 242, 242));
        manageAccounts.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/user.png"))); // NOI18N
        manageAccounts.setText("MANAGE ACCOUNTS");
        manageAccounts.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        manageAccounts.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);

        logout.setBackground(new java.awt.Color(0, 0, 153));
        logout.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        logout.setForeground(new java.awt.Color(242, 242, 242));
        logout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/logout.png"))); // NOI18N
        logout.setText("LOGOUT");
        logout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        logout.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        logout.addActionListener(this::logoutActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addGap(60, 60, 60))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminHome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(manageTutors, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(manageAppointments, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(manageAccounts, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(logout, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(55, 55, 55)
                .addComponent(adminHome, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(manageTutors, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(manageAppointments, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(manageAccounts, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 135, Short.MAX_VALUE)
                .addComponent(logout, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));
        jPanel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Manage Accounts");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(407, 407, 407)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(23, 23, 23))
        );

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("View and manage student, tutor, and admin accounts.");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Search:");

        searchField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        searchButton.setBackground(new java.awt.Color(0, 0, 153));
        searchButton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        searchButton.setForeground(new java.awt.Color(242, 242, 242));
        searchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/tutorappointmentsystem/magnifying-glass.png"))); // NOI18N
        searchButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        searchButton.addActionListener(this::searchButtonActionPerformed);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Role:");

        roleComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("Status:");

        statusComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        refreshButton.setBackground(new java.awt.Color(0, 0, 153));
        refreshButton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        refreshButton.setForeground(new java.awt.Color(242, 242, 242));
        refreshButton.setText("Refresh");
        refreshButton.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        refreshButton.addActionListener(this::refreshButtonActionPerformed);

        accountsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "User ID", "Full Name", "Email", "Role", "Account Status", "Action"
            }
        ));
        accountsTable.setGridColor(new java.awt.Color(0, 0, 0));
        accountsTable.setRowHeight(40);
        accountsTable.setSelectionBackground(new java.awt.Color(153, 153, 153));
        accountsTable.setShowGrid(true);
        jScrollPane1.setViewportView(accountsTable);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jLabel9))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1078, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(searchField, javax.swing.GroupLayout.PREFERRED_SIZE, 543, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(26, 26, 26)
                                        .addComponent(searchButton, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(32, 32, 32)
                                        .addComponent(refreshButton, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(roleComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(173, 173, 173)
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(statusComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel9)
                .addGap(72, 72, 72)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(searchButton, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                            .addComponent(searchField)
                            .addComponent(jLabel10)
                            .addComponent(refreshButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(47, 47, 47)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(roleComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12)))
                    .addComponent(statusComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(44, 44, 44)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(217, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 122, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1540, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        String keyword = searchField.getText().trim().toLowerCase();

    if (keyword.isEmpty()) {
        loadAccounts();
        return;
    }

    javax.swing.table.DefaultTableModel model =
            (javax.swing.table.DefaultTableModel) accountsTable.getModel();

    model.setRowCount(0);

    String sql = "SELECT user_id, full_name, email, role, account_status " +
            "FROM users " +
            "WHERE CAST(user_id AS CHAR) LIKE ? " +
            "OR LOWER(full_name) LIKE ? " +
            "OR LOWER(email) LIKE ? " +
            "ORDER BY user_id ASC";

    try (java.sql.Connection con = DBConnection.getConnection();
         java.sql.PreparedStatement pst = con.prepareStatement(sql)) {

        String search = "%" + keyword + "%";

        pst.setString(1, search);
        pst.setString(2, search);
        pst.setString(3, search);

        try (java.sql.ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("role"),
                    rs.getString("account_status"),
                    "Manage"
                });
            }
        }

        if (model.getRowCount() == 0) {
            javax.swing.JOptionPane.showMessageDialog(
                    this,
                    "No accounts found.",
                    "Search Results",
                    javax.swing.JOptionPane.INFORMATION_MESSAGE
            );
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
                this,
                "Unable to search accounts: " + e.getMessage(),
                "Database Error",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );
    }
    }//GEN-LAST:event_searchButtonActionPerformed

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        searchField.setText("");
        roleComboBox.setSelectedIndex(0);
        statusComboBox.setSelectedIndex(0);

    loadAccounts();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void manageAppointmentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageAppointmentsActionPerformed
        ManageAppointments manageAppointments = new ManageAppointments();
        manageAppointments.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_manageAppointmentsActionPerformed

    private void adminHomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminHomeActionPerformed
        AdminHome adminHome = new AdminHome();
        adminHome.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_adminHomeActionPerformed

    private void manageTutorsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_manageTutorsActionPerformed
        ManageTutors manageTutors = new ManageTutors();
        manageTutors.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_manageTutorsActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        int choice = JOptionPane.showConfirmDialog(
        this,
        "Are you sure you want to logout?",
        "Confirm Logout",
        JOptionPane.YES_NO_OPTION
);

if (choice == JOptionPane.YES_OPTION) {

    UserSession.clearSession();

    Login login = new Login();
    login.setVisible(true);
    this.dispose();
}
    }//GEN-LAST:event_logoutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new ManageAccounts().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable accountsTable;
    private javax.swing.JButton adminHome;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton logout;
    private javax.swing.JButton manageAccounts;
    private javax.swing.JButton manageAppointments;
    private javax.swing.JButton manageTutors;
    private javax.swing.JButton refreshButton;
    private javax.swing.JComboBox<String> roleComboBox;
    private javax.swing.JButton searchButton;
    private javax.swing.JTextField searchField;
    private javax.swing.JComboBox<String> statusComboBox;
    // End of variables declaration//GEN-END:variables
}
